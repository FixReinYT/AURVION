from pathlib import Path
import cairosvg
from PIL import Image

root = Path(__file__).resolve().parents[1]
assets = root / "assets"
svg = assets / "AURVION.svg"
png = assets / "AURVION.png"
cairosvg.svg2png(url=str(svg), write_to=str(png), output_width=1024, output_height=1024)
image = Image.open(png).convert("RGBA")
image.save(assets / "AURVION.ico", format="ICO", sizes=[(16,16),(24,24),(32,32),(48,48),(64,64),(96,96),(128,128),(192,192),(256,256)])
image.convert("RGB").save(assets / "AURVION.jpeg", format="JPEG", quality=94, optimize=True)
png.unlink(missing_ok=True)
print("Generated AURVION.ico and AURVION.jpeg from AURVION.svg")
