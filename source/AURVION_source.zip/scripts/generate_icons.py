from pathlib import Path
from PIL import Image
from PySide6.QtCore import Qt
from PySide6.QtGui import QImage, QPainter
from PySide6.QtSvg import QSvgRenderer

root = Path(__file__).resolve().parents[1]
assets = root / "assets"
svg = assets / "AURVION.svg"
png = assets / "AURVION.png"
renderer = QSvgRenderer(str(svg))
if not renderer.isValid():
    raise RuntimeError(f"Invalid SVG logo: {svg}")
canvas = QImage(1024, 1024, QImage.Format_ARGB32)
canvas.fill(Qt.transparent)
painter = QPainter(canvas)
renderer.render(painter)
painter.end()
if not canvas.save(str(png), "PNG"):
    raise RuntimeError("Could not render AURVION.svg")
image = Image.open(png).convert("RGBA")
image.save(assets / "AURVION.ico", format="ICO", sizes=[(16,16),(24,24),(32,32),(48,48),(64,64),(96,96),(128,128),(192,192),(256,256)])
image.convert("RGB").save(assets / "AURVION.jpeg", format="JPEG", quality=94, optimize=True)
png.unlink(missing_ok=True)
print("Generated AURVION.ico and AURVION.jpeg from AURVION.svg using QtSvg + Pillow")
