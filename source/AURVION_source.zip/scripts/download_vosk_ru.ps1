$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
$models = Join-Path $root "models"
$name = "vosk-model-small-ru-0.22"
$target = Join-Path $models $name
$zip = Join-Path $models "$name.zip"
$tmp = Join-Path $models "_extract"
New-Item -ItemType Directory -Force -Path $models | Out-Null
if (Test-Path $target) { Write-Host "Vosk model already installed."; exit 0 }
Write-Host "Downloading Russian Vosk model (one-time download)..."
Invoke-WebRequest "https://alphacephei.com/vosk/models/vosk-model-small-ru-0.22.zip" -OutFile $zip
if (Test-Path $tmp) { Remove-Item $tmp -Recurse -Force }
Expand-Archive $zip $tmp -Force
$folder = Join-Path $tmp $name
if (!(Test-Path $folder)) { $folder = (Get-ChildItem $tmp -Directory | Select-Object -First 1).FullName }
Move-Item $folder $target
Remove-Item $zip -Force; Remove-Item $tmp -Recurse -Force
Write-Host "Done. Offline speech recognition model installed."
