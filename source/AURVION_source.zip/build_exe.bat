@echo off
cd /d "%~dp0"
if not exist "models\vosk-model-small-ru-0.22" (
 echo First install the Vosk model using scripts\download_vosk_ru.bat
 pause
 exit /b 1
)
python scripts\generate_icons.py
if errorlevel 1 exit /b 1
pyinstaller --noconfirm --clean --windowed --onedir --name AURVION --icon "assets\AURVION.ico" ^
 --collect-all vosk --collect-all sounddevice --collect-all pyttsx3 ^
 --hidden-import win32com.client --hidden-import comtypes ^
 --add-data "assets;assets" --add-data "models;models" main.py
echo Build output: dist\AURVION
pause
