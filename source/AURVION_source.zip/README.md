# AURVION

AURVION is a local-first Windows voice assistant prototype. It is designed for offline speech recognition, optional local GGUF inference, controlled desktop automation, voice/personality settings, and Windows background startup.

## Build from source (Windows 10/11 x64)

1. Install Python 3.11 x64.
2. Run `setup_windows.bat`.
3. Run `scripts\download_vosk_ru.bat` to download the Russian offline speech model.
4. Run `run_windows.bat` for a source-mode test.
5. Run `build_installer.bat` to generate the PyInstaller app folder.
6. Compile `installer\AURVION_Setup.iss` with Inno Setup 6.

GitHub Actions workflow `AURVION Windows installer` performs these steps on a hosted Windows runner and uploads the setup executable as an artifact.

## Runtime notes

- No cloud LLM is required. A GGUF model must be selected separately in the app; the model is not bundled.
- Startup is per-user and optional. The app runs in the interactive desktop session, not as a hidden SYSTEM service.
- Windows UAC remains in control of administrator-level actions.
- Desktop automation is allow-listed; do not treat heuristic safety filters as a complete security boundary.
- Computers managed by a school or employer may block portable apps or background microphone access. Respect their policies.

## Uninstall

The installer is per-user (`PrivilegesRequired=lowest`). Uninstall removes the installed application and its startup registration. User settings and conversation history are kept in `%APPDATA%\AURVION` so that uninstalling does not silently erase user data; delete that folder manually if a full data wipe is desired.
