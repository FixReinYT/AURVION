@echo off
setlocal
cd /d "%~dp0"
echo [1/2] Building Windows application with PyInstaller...
if not exist ".venv\Scripts\activate.bat" (
  echo Virtual environment missing. Run setup_windows.bat first.
  pause
  exit /b 1
)
call .venv\Scripts\activate
echo Generating AURVION branding assets...
python scripts\generate_icons.py
if errorlevel 1 exit /b 1
pyinstaller --noconfirm --clean --windowed --onedir --name AURVION ^
 --collect-all vosk --collect-all sounddevice --collect-all pyttsx3 ^
 --collect-all PySide6 --hidden-import win32com.client --hidden-import comtypes ^
 --icon "assets\AURVION.ico" --add-data "assets;assets" --add-data "models;models" main.py
if errorlevel 1 (
  echo PyInstaller build failed.
  pause
  exit /b 1
)
echo [2/2] Install Inno Setup 6 and compile installer\AURVION_Setup.iss
echo The installer source is ready. Inno Setup compiler is required to create Setup.exe.
pause
