#define MyAppName "AURVION"
#define MyAppVersion "0.3.0"
#define MyAppPublisher "AURVION Project"
#define MyAppExeName "AURVION.exe"

[Setup]
AppId={{8B1D6B5E-AB3C-4D4B-A0F1-000000000021}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={localappdata}\Programs\AURVION
DefaultGroupName={#MyAppName}
DisableProgramGroupPage=yes
PrivilegesRequired=lowest
OutputDir=Output
OutputBaseFilename=AURVION_Setup_{#MyAppVersion}
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
ArchitecturesInstallIn64BitMode=x64
SetupIconFile=..\assets\AURVION.ico
UninstallDisplayIcon={app}\assets\AURVION.ico

[Tasks]
Name: "desktopicon"; Description: "Создать ярлык на рабочем столе"; GroupDescription: "Дополнительные параметры:"; Flags: unchecked
Name: "startup"; Description: "Запускать AURVION автоматически при входе в Windows"; GroupDescription: "Дополнительные параметры:"; Flags: checkedonce

[Files]
; Build the PyInstaller onedir output first. This installer packages the entire folder.
Source: "..\dist\AURVION\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{autoprograms}\AURVION"; Filename: "{app}\{#MyAppExeName}"
Name: "{autodesktop}\AURVION"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Registry]
Root: HKCU; Subkey: "Software\Microsoft\Windows\CurrentVersion\Run"; ValueType: string; ValueName: "AURVION"; ValueData: """{app}\{#MyAppExeName}"" --background"; Tasks: startup; Flags: uninsdeletevalue

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Запустить AURVION"; Flags: postinstall nowait skipifsilent

[UninstallDelete]
Type: files; Name: "{userstartup}\AURVION.lnk"
