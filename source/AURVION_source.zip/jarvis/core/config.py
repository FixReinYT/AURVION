from __future__ import annotations
import json, os, sys
from pathlib import Path

APP_DIR_NAME = "AURVION"

DEFAULTS = {
    "assistant_name": "Аурвион",
    "wake_phrase": "эй аурвион",
    "wake_enabled": True,
    "personality": "classic",
    "custom_personality": "Говори понятно и по делу. Используй лёгкий юмор, когда он уместен.",
    "voice_id": "",
    "voice_rate": 175,
    "model_path": "",
    "model_context": 4096,
    "model_threads": 0,
    "llm_enabled": False,
    "confirm_file_changes": True,
    "confirm_system_actions": True,
    "start_minimized": False
}

def app_root() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parents[2]

def data_dir() -> Path:
    base = Path(os.environ.get("APPDATA", str(Path.home())))
    p = base / APP_DIR_NAME
    p.mkdir(parents=True, exist_ok=True)
    return p

def config_file() -> Path:
    return data_dir() / "settings.json"

def load_config() -> dict:
    path = config_file()
    if not path.exists():
        save_config(DEFAULTS)
        return DEFAULTS.copy()
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
        merged = DEFAULTS.copy()
        if isinstance(raw, dict):
            merged.update(raw)
        return merged
    except Exception:
        return DEFAULTS.copy()

def save_config(config: dict) -> None:
    safe = DEFAULTS.copy()
    safe.update(config)
    config_file().write_text(json.dumps(safe, ensure_ascii=False, indent=2), encoding="utf-8")

def resolve_model_path(config: dict) -> Path | None:
    raw = str(config.get("model_path", "")).strip()
    if not raw:
        return None
    p = Path(raw).expanduser()
    return p.resolve()


def asset_path(*parts: str) -> Path:
    """Resolve bundled assets in source and PyInstaller onedir builds."""
    import sys
    if getattr(sys, "frozen", False):
        base = Path(sys._MEIPASS)
    else:
        base = app_root()
    return base.joinpath(*parts)
