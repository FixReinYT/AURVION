from __future__ import annotations
from .safeguard import requires_confirmation
from jarvis.tools import windows_tools, file_tools, steam_tools, system_tools

class ToolRegistry:
    def __init__(self, config):
        self.config = config
        self.handlers = {
            "open_url": windows_tools.open_url,
            "open_app": windows_tools.open_app,
            "press_key": windows_tools.press_key,
            "click": windows_tools.click,
            "type_text": windows_tools.type_text,
            "scroll": windows_tools.scroll,
            "open_folder": file_tools.open_folder,
            "search_files": file_tools.search_files,
            "copy_file": file_tools.copy_file,
            "move_file": file_tools.move_file,
            "delete_file": file_tools.delete_file,
            "launch_steam_game": steam_tools.launch_game,
            "list_steam_games": steam_tools.list_games,
            "set_volume": system_tools.set_volume,
            "take_screenshot": system_tools.take_screenshot,
            "system_status": system_tools.system_status,
            "tell_time": system_tools.tell_time,
            "close_process": system_tools.close_process,
        }

    def execute(self, name, args):
        handler = self.handlers.get(name)
        if not handler:
            return f"Ошибка: инструмент «{name}» не разрешён."
        try:
            return str(handler(**args))
        except TypeError:
            return "Ошибка: неверные аргументы инструмента."
        except Exception as exc:
            return "Ошибка: " + str(exc)

    def try_simple_command(self, text):
        t = text.lower().strip()
        import re
        from jarvis.tools import windows_tools, file_tools, system_tools, steam_tools
        if "youtube" in t or "ютуб" in t:
            return windows_tools.open_url("https://www.youtube.com")
        if "открой браузер" in t:
            return windows_tools.open_url("about:blank")
        if "открой steam" in t or "запусти steam" in t:
            return windows_tools.open_app("steam")
        m = re.search(r"(?:запусти|включи)(?: игру)?\s+(.+)$", t)
        if m and ("игру" in t or "minecraft" in t or "майнкрафт" in t):
            return steam_tools.launch_game(m.group(1).replace("игру","").strip())
        m = re.search(r"громкость(?: на)?\s+(\d{1,3})", t)
        if m: return system_tools.set_volume(int(m.group(1)))
        if "скриншот" in t: return system_tools.take_screenshot()
        if "который час" in t or "скажи время" in t: return system_tools.tell_time()
        for folder in ["документы","загрузки","рабочий стол","изображения","музыка","видео"]:
            if folder in t and ("открой" in t or "покажи" in t):
                return file_tools.open_folder(folder)
        return None
