from __future__ import annotations
from .safeguard import inspect_user_request, inspect_assistant_output, requires_confirmation
from .tools_registry import ToolRegistry

class Agent:
    def __init__(self, brain, memory, config):
        self.brain, self.memory, self.config = brain, memory, config
        self.tools = ToolRegistry(config)

    def handle(self, text, confirm_callback=None):
        check = inspect_user_request(text)
        if not check.allowed:
            self.memory.add_message("user", text)
            self.memory.add_message("assistant", check.reason)
            return check.reason

        self.memory.add_message("user", text)
        if not self.brain or not self.brain.ready:
            response = self.tools.try_simple_command(text)
            if response is None:
                response = ("Локальная нейросеть пока не подключена. Я могу выполнять встроенные команды, "
                            "а для свободного диалога выбери GGUF-модель в настройках.")
            self.memory.add_message("assistant", response)
            return response

        try:
            plan = self.brain.ask(text, self.memory.recent(12)[:-1])
        except Exception as exc:
            response = "Ошибка локальной модели: " + str(exc)
            self.memory.add_message("assistant", response)
            return response

        # Inspect the model's structured output before executing any proposed tool.
        import json
        raw_plan = json.dumps(plan, ensure_ascii=False) if isinstance(plan, dict) else str(plan)
        plan_check = inspect_assistant_output(raw_plan)
        if not plan_check.allowed:
            response = "План остановлен защитным фильтром. Действия не выполнялись."
        elif not isinstance(plan, dict):
            response = "Модель вернула ответ в неизвестном формате."
        elif plan.get("kind") == "message":
            response = str(plan.get("text", "Не удалось сформировать ответ."))
        elif plan.get("kind") in {"tool", "plan"}:
            steps = [plan] if plan.get("kind") == "tool" else plan.get("steps", [])
            if not isinstance(steps, list) or len(steps) > 5:
                response = "План отклонён: допускается не более пяти последовательных действий."
            else:
                results = []
                for step in steps:
                    if not isinstance(step, dict):
                        results.append("Некорректный шаг плана."); break
                    name, args = step.get("name"), step.get("arguments", {})
                    if plan.get("kind") == "tool":
                        name, args = plan.get("name"), plan.get("arguments", {})
                    if not isinstance(args, dict):
                        results.append("Некорректные аргументы."); break
                    if requires_confirmation(name, args):
                        if not confirm_callback or not confirm_callback(name, args):
                            results.append(f"Действие {name} отменено: подтверждение не получено.")
                            break
                    result = self.tools.execute(name, args)
                    results.append(result)
                    if result.startswith("Ошибка:"):
                        break
                response = str(plan.get("say", "Готово.")) + "\n" + "\n".join(results)
        else:
            response = "Не удалось понять формат ответа локальной модели."
        output_check = inspect_assistant_output(response)
        if not output_check.allowed:
            response = "Ответ остановлен защитным фильтром. Попробуй сформулировать безопасный запрос."
        self.memory.add_message("assistant", response)
        return response
