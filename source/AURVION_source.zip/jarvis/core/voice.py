from __future__ import annotations
import json, queue, threading, time
from pathlib import Path
from PySide6.QtCore import QThread, Signal

class SpeechListener(QThread):
    command = Signal(str); status = Signal(str); error = Signal(str)
    def __init__(self, model_dir, wake_phrase, wake_enabled=True):
        super().__init__(); self.model_dir=Path(model_dir); self.wake_phrase=wake_phrase.lower()
        self.wake_enabled=wake_enabled; self._stop=threading.Event(); self._arm=threading.Event()
    def stop(self): self._stop.set()
    def arm(self): self._arm.set()
    def set_wake(self,value): self.wake_enabled=bool(value)
    def run(self):
        if not self.model_dir.exists():
            self.error.emit(f"Не найдена модель Vosk: {self.model_dir}. Запусти scripts/download_vosk_ru.bat.")
            return
        try:
            import sounddevice as sd
            from vosk import Model, KaldiRecognizer
            q=queue.Queue(); model=Model(str(self.model_dir)); rec=KaldiRecognizer(model,16000)
            def callback(indata,frames,t,status): q.put(bytes(indata))
            armed=False; deadline=0
            self.status.emit("Микрофон активен. Ожидаю имя помощника.")
            with sd.RawInputStream(samplerate=16000,blocksize=8000,dtype="int16",channels=1,callback=callback):
                while not self._stop.is_set():
                    if self._arm.is_set():
                        self._arm.clear(); armed=True; deadline=time.monotonic()+12; rec=KaldiRecognizer(model,16000)
                        self.status.emit("Слушаю команду.")
                    if armed and time.monotonic()>deadline:
                        armed=False; rec=KaldiRecognizer(model,16000); self.status.emit("Ожидаю имя помощника.")
                    try: data=q.get(timeout=.2)
                    except queue.Empty: continue
                    if not rec.AcceptWaveform(data): continue
                    phrase=" ".join(json.loads(rec.Result()).get("text","").lower().split())
                    if not phrase: continue
                    if armed:
                        self.command.emit(phrase); armed=False; rec=KaldiRecognizer(model,16000)
                        self.status.emit("Команда распознана.")
                    elif self.wake_enabled and self.wake_phrase in phrase:
                        tail=phrase.split(self.wake_phrase,1)[1].strip()
                        if tail: self.command.emit(tail)
                        else: armed=True; deadline=time.monotonic()+12; self.status.emit("Слушаю команду.")
                        rec=KaldiRecognizer(model,16000)
        except Exception as exc:
            self.error.emit("Ошибка голосового ввода: "+str(exc))

class SpeechOutput(QThread):
    done=Signal()
    def __init__(self,text,voice_id="",rate=175):
        super().__init__(); self.text=text; self.voice_id=voice_id; self.rate=rate
    def run(self):
        try:
            import pyttsx3
            engine=pyttsx3.init(driverName="sapi5")
            if self.voice_id: engine.setProperty("voice",self.voice_id)
            engine.setProperty("rate",int(self.rate)); engine.say(self.text); engine.runAndWait(); engine.stop()
        except Exception: pass
        self.done.emit()

def available_voices():
    try:
        import pyttsx3
        engine=pyttsx3.init(driverName="sapi5")
        voices=[(v.id,v.name) for v in engine.getProperty("voices")]
        engine.stop(); return voices
    except Exception: return []
