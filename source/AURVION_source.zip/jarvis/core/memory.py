from __future__ import annotations
import sqlite3
from pathlib import Path
from .config import data_dir

class MemoryStore:
    def __init__(self):
        self.path = data_dir() / "memory.sqlite3"
        self._init()

    def _connect(self):
        return sqlite3.connect(self.path)

    def _init(self):
        with self._connect() as db:
            db.execute("""CREATE TABLE IF NOT EXISTS messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                role TEXT NOT NULL,
                content TEXT NOT NULL,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )""")
            db.execute("""CREATE TABLE IF NOT EXISTS notes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                content TEXT NOT NULL,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )""")

    def add_message(self, role, content):
        with self._connect() as db:
            db.execute("INSERT INTO messages(role, content) VALUES(?,?)", (role, content[:12000]))

    def recent(self, limit=12):
        with self._connect() as db:
            rows = db.execute(
                "SELECT role, content FROM messages ORDER BY id DESC LIMIT ?", (int(limit),)
            ).fetchall()
        return [{"role": r, "content": c} for r, c in reversed(rows)]

    def clear_history(self):
        with self._connect() as db:
            db.execute("DELETE FROM messages")

    def add_note(self, title, content):
        with self._connect() as db:
            db.execute("INSERT INTO notes(title, content) VALUES(?,?)", (title[:200], content[:4000]))

    def notes(self):
        with self._connect() as db:
            return db.execute("SELECT id,title,content,created_at FROM notes ORDER BY id DESC").fetchall()

    def delete_note(self, note_id):
        with self._connect() as db:
            db.execute("DELETE FROM notes WHERE id=?", (int(note_id),))
