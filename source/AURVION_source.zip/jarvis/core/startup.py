from __future__ import annotations
import sys
from pathlib import Path

RUN_KEY = r"Software\Microsoft\Windows\CurrentVersion\Run"
VALUE_NAME = "AURVION"

def executable_command():
    if getattr(sys, "frozen", False):
        exe = Path(sys.executable).resolve()
        return f'"{exe}" --background'
    script = Path(__file__).resolve().parents[2] / "main.py"
    python = Path(sys.executable).resolve()
    return f'"{python}" "{script}" --background'

def enable_startup():
    if sys.platform != "win32":
        return False, "Автозапуск поддерживается только в Windows."
    import winreg
    with winreg.CreateKey(winreg.HKEY_CURRENT_USER, RUN_KEY) as key:
        winreg.SetValueEx(key, VALUE_NAME, 0, winreg.REG_SZ, executable_command())
    return True, "Автозапуск AURVION включён для текущего пользователя."

def disable_startup():
    if sys.platform != "win32":
        return False, "Автозапуск поддерживается только в Windows."
    import winreg
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY, 0, winreg.KEY_SET_VALUE) as key:
            winreg.DeleteValue(key, VALUE_NAME)
    except FileNotFoundError:
        pass
    return True, "Автозапуск AURVION отключён."

def is_startup_enabled():
    if sys.platform != "win32":
        return False
    import winreg
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY) as key:
            winreg.QueryValueEx(key, VALUE_NAME)
            return True
    except OSError:
        return False
