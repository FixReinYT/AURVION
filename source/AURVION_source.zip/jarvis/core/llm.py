from __future__ import annotations
import json
from pathlib import Path
from .personality import system_prompt

class LocalBrain:
    """Optional llama.cpp GGUF backend. Model file is selected by the user and stays local."""
    def __init__(self, config):
        self.config = config
        self.model = None
        self.error = ""
        self.path = Path(config.get("model_path", "")).expanduser() if config.get("model_path") else None

    @property
    def ready(self):
        return self.model is not None

    def load(self):
        if not self.path or not self.path.is_file():
            self.error = "GGUF-модель не выбрана. Укажи файл модели в настройках."
            return False
        try:
            from llama_cpp import Llama
            threads = int(self.config.get("model_threads", 0))
            if threads <= 0:
                import os
                threads = max(2, (os.cpu_count() or 4) - 1)
            self.model = Llama(
                model_path=str(self.path),
                n_ctx=int(self.config.get("model_context", 4096)),
                n_threads=threads,
                n_gpu_layers=0,
                verbose=False
            )
            return True
        except Exception as exc:
            self.error = str(exc)
            return False

    def unload(self):
        self.model = None

    def ask(self, user_text, history):
        if not self.model:
            return None
        messages = [{"role":"system","content":system_prompt(self.config)}]
        for item in history[-10:]:
            if item["role"] in {"user","assistant"}:
                messages.append({"role":item["role"],"content":item["content"]})
        messages.append({"role":"user","content":user_text})
        result = self.model.create_chat_completion(
            messages=messages,
            temperature=0.35,
            max_tokens=700,
            response_format={"type":"json_object"}
        )
        raw = result["choices"][0]["message"]["content"]
        try:
            return json.loads(raw)
        except Exception:
            return {"kind":"message","text":raw}
