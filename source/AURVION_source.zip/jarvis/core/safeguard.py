from __future__ import annotations
import re
from dataclasses import dataclass

@dataclass
class SafetyResult:
    allowed: bool
    reason: str = ""
    category: str = ""

# This is a conservative first-pass heuristic, not a complete content classifier.
# OS security is enforced separately by the tool allow-list and argument validation.
BLOCK_PATTERNS = [
    ("sexual_content_involving_minors", [
        r"(порно|эротик|секс|сексуальн).{0,50}(реб[её]н|несовершеннолет|школьниц|школьник)",
        r"(реб[её]н|несовершеннолет|школьниц|школьник).{0,50}(порно|эротик|секс|сексуальн|обнаж|гол)",
        r"(порно|эротик|секс|сексуальн|обнаж|гол).{0,50}(реб[её]н|несовершеннолет|школьниц|школьник)",
        r"(?:[0-9]|1[0-7])[- ]?летн.{0,40}(порно|эротик|секс|сексуальн|обнаж|гол)",
        r"(порно|эротик|секс|сексуальн|обнаж|гол).{0,40}(?:[0-9]|1[0-7])\s*лет",
        r"\b(child|minor).{0,40}(porn|sexual|nude)",
        r"\b(porn|sexual|nude).{0,40}(child|minor)",
        r"\b(?:[0-9]|1[0-7])[- ]year[- ]old.{0,50}(porn|sexual|nude)",
        r"\b(porn|sexual|nude).{0,50}\b(?:[0-9]|1[0-7])[- ]year[- ]old"
    ]),
    ("malware_creation", [
        r"(создай|напиши|сделай|разработай).{0,60}(вирус|троян|шифровальщик|стилер|кейлоггер)",
        r"(создай|напиши|сделай).{0,60}(malware|ransomware|keylogger|stealer)"
    ]),
    ("credential_theft", [
        r"(укради|похити|собери).{0,60}(парол|cookie|токен|уч[её]тн)",
        r"(steal|harvest).{0,60}(password|cookie|credential|token)"
    ]),
    ("weapon_or_explosive_instructions", [
        r"(инструкц|рецепт|схем).{0,60}(бомб|взрывчат|самодельн.{0,20}оруж)",
        r"(изготов|сделать|собрать).{0,60}(бомб|взрывчат)"
    ])
]

def inspect_user_request(text: str) -> SafetyResult:
    value = " ".join(str(text).lower().split())
    for category, patterns in BLOCK_PATTERNS:
        if any(re.search(p, value, re.IGNORECASE) for p in patterns):
            return SafetyResult(False, "Я не могу помогать с этим запросом. Могу предложить безопасную альтернативу.", category)
    return SafetyResult(True)

def inspect_assistant_output(text: str) -> SafetyResult:
    # A second, lightweight check catches obvious unsafe generations.
    # This is not a substitute for a tested classifier or human review.
    return inspect_user_request(text)

def requires_confirmation(tool_name: str, args: dict) -> bool:
    if tool_name in {"delete_file", "move_file", "copy_file", "close_process",
                     "shutdown_pc", "restart_pc", "click", "type_text", "press_key"}:
        return True
    return False
