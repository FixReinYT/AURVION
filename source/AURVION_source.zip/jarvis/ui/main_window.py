from __future__ import annotations
from PySide6.QtWidgets import *
from PySide6.QtCore import Qt
from PySide6.QtGui import QFont, QAction, QIcon, QPixmap
from PySide6.QtSvgWidgets import QSvgWidget
from pathlib import Path
from jarvis.core.config import load_config, save_config, app_root, asset_path
from jarvis.core.memory import MemoryStore
from jarvis.core.llm import LocalBrain
from jarvis.core.agent import Agent
from jarvis.core.personality import PRESETS
from jarvis.core import startup
from jarvis.core.voice import SpeechListener, SpeechOutput, available_voices

class MainWindow(QMainWindow):
    def __init__(self, start_hidden=False):
        super().__init__()
        self.start_hidden = start_hidden
        self._allow_exit = False
        self.tray = None
        self.setWindowIcon(QIcon(str(asset_path("assets", "AURVION.ico"))))
        self.cfg=load_config(); self.memory=MemoryStore()
        self.brain=LocalBrain(self.cfg)
        self.agent=Agent(self.brain,self.memory,self.cfg)
        self.listener=None; self.speaker=None
        self.setWindowTitle("AURVION — Голосовой помощник")
        self.resize(1050,760); self._build_ui(); self._load_voices()
        self._restore_history(); self._start_listener(); self._setup_tray()
    def _build_ui(self):
        central=QWidget(); self.setCentralWidget(central); outer=QVBoxLayout(central)
        brand_row=QHBoxLayout()
        brand_mark=QSvgWidget(str(asset_path("assets", "AURVION.svg")))
        brand_mark.setFixedSize(58,58)
        title=QLabel("AURVION")
        title.setStyleSheet("font-size:26px;font-weight:700;color:#dcecff")
        brand_row.addWidget(brand_mark)
        brand_row.addWidget(title)
        brand_row.addStretch()
        outer.addLayout(brand_row)
        self.status=QLabel("Инициализация...")
        outer.addWidget(self.status)
        self.tabs=QTabWidget(); outer.addWidget(self.tabs,1)
        self._chat_tab()
        self.tabs.addTab(self._control_tab(),"Управление ПК")
        self.tabs.addTab(self._personality_tab(),"Личность")
        self.tabs.addTab(self._voice_tab(),"Голос")
        self.tabs.addTab(self._memory_tab(),"Память")
        self.tabs.addTab(self._safety_tab(),"Безопасность")
        self.tabs.addTab(self._model_tab(),"Локальный ИИ")
        self.tabs.addTab(self._startup_tab(),"Автозапуск")
        self.tabs.addTab(self._about_tab(),"О программе")
        self.tabs.addTab(self._settings_tab(),"Настройки")
        self.setStyleSheet("""
          QMainWindow,QWidget{background:#101722;color:#e8eef6;font-size:10pt}
          QPlainTextEdit,QLineEdit,QComboBox,QTextEdit{background:#192536;border:1px solid #354b65;border-radius:6px;padding:8px;color:#edf5ff}
          QPushButton{background:#245c8b;border:0;border-radius:6px;padding:9px 13px}
          QPushButton:hover{background:#347bb4}
          QTabWidget::pane{border:1px solid #30445c}
          QTabBar::tab{background:#1a2636;padding:10px 14px;margin:2px}
          QTabBar::tab:selected{background:#28577e}
          QGroupBox{border:1px solid #354b65;border-radius:7px;margin-top:10px;padding:10px}
          QLabel#muted{color:#9eafc3}
        """)
    def _chat_tab(self):
        w=QWidget(); l=QVBoxLayout(w)
        self.chat=QPlainTextEdit(); self.chat.setReadOnly(True); l.addWidget(self.chat,1)
        row=QHBoxLayout(); self.prompt=QLineEdit(); self.prompt.setPlaceholderText("Напиши команду или вопрос...")
        self.prompt.returnPressed.connect(self._send); send=QPushButton("Отправить"); send.clicked.connect(self._send)
        row.addWidget(self.prompt,1); row.addWidget(send); l.addLayout(row)
        controls=QHBoxLayout()
        mic=QPushButton("Нажми и говори"); mic.clicked.connect(self._arm_listener); controls.addWidget(mic)
        stop=QPushButton("Остановить голос"); stop.clicked.connect(self._stop_speech); controls.addWidget(stop)
        l.addLayout(controls)
        return w
    def _control_tab(self):
        w=QWidget(); l=QVBoxLayout(w)
        l.addWidget(QLabel("Инструменты, доступные локальному агенту"))
        grid=QGridLayout()
        actions=[
            ("Открыть YouTube","open_url"),("Открыть Steam","open_app"),
            ("Список игр Steam","list_steam_games"),("Диагностика ПК","system_status"),
            ("Скриншот","take_screenshot"),("Сказать время","tell_time")
        ]
        for i,(label,tool) in enumerate(actions):
            b=QPushButton(label); b.clicked.connect(lambda checked=False,t=tool:self._run_manual(t)); grid.addWidget(b,i//2,i%2)
        l.addLayout(grid)
        l.addWidget(QLabel("Голосовые команды и локальный ИИ могут вызывать только зарегистрированные инструменты."))
        l.addStretch(); return w
    def _personality_tab(self):
        w=QWidget(); l=QVBoxLayout(w)
        l.addWidget(QLabel("Характер меняет только манеру общения. Он не меняет права доступа и правила безопасности."))
        self.persona=QComboBox()
        for key,(label,_) in PRESETS.items(): self.persona.addItem(label,key)
        idx=self.persona.findData(self.cfg.get("personality","classic")); self.persona.setCurrentIndex(max(0,idx))
        l.addWidget(QLabel("Готовый характер")); l.addWidget(self.persona)
        l.addWidget(QLabel("Описание собственного характера"))
        self.custom=QTextEdit(); self.custom.setMaximumHeight(130); self.custom.setPlainText(self.cfg.get("custom_personality",""))
        l.addWidget(self.custom)
        self.preview=QLabel(); self.preview.setWordWrap(True); l.addWidget(self.preview)
        self.persona.currentIndexChanged.connect(self._preview_persona); self.custom.textChanged.connect(self._preview_persona)
        row=QHBoxLayout(); save=QPushButton("Сохранить"); save.clicked.connect(self._save_persona)
        reset=QPushButton("Сбросить"); reset.clicked.connect(self._reset_persona)
        row.addWidget(save); row.addWidget(reset); l.addLayout(row); l.addStretch()
        self._preview_persona(); return w
    def _voice_tab(self):
        w=QWidget(); l=QVBoxLayout(w); l.addWidget(QLabel("Системные голоса Windows SAPI5"))
        self.voice=QComboBox(); l.addWidget(self.voice)
        self.rate=QSlider(Qt.Horizontal); self.rate.setRange(120,240); self.rate.setValue(int(self.cfg.get("voice_rate",175)))
        l.addWidget(QLabel("Скорость речи")); l.addWidget(self.rate)
        save=QPushButton("Сохранить голос"); save.clicked.connect(self._save_voice); l.addWidget(save)
        test=QPushButton("Проверить"); test.clicked.connect(lambda:self._speak("Проверка голосового модуля.")); l.addWidget(test)
        l.addWidget(QLabel("Дополнительные голоса Piper можно подключить отдельным пакетом в следующей сборке."))
        l.addStretch(); return w
    def _memory_tab(self):
        w=QWidget(); l=QVBoxLayout(w)
        l.addWidget(QLabel("История хранится локально в SQLite на этом компьютере."))
        self.memory_view=QPlainTextEdit(); self.memory_view.setReadOnly(True); l.addWidget(self.memory_view,1)
        row=QHBoxLayout(); refresh=QPushButton("Обновить"); refresh.clicked.connect(self._refresh_memory)
        clear=QPushButton("Очистить историю"); clear.clicked.connect(self._clear_memory)
        row.addWidget(refresh); row.addWidget(clear); l.addLayout(row)
        self._refresh_memory(); return w
    def _safety_tab(self):
        w=QWidget(); l=QVBoxLayout(w)
        l.addWidget(QLabel("JARVIS SAFEGUARD"))
        for line in [
            "Характер пользователя не может менять системную инструкцию безопасности.",
            "Нет инструмента произвольного запуска CMD или PowerShell.",
            "Файловые инструменты ограничены домашней папкой пользователя.",
            "Удаление, перемещение и завершение процессов требуют подтверждения.",
            "Защита от сексуального контента с несовершеннолетними и некоторых запросов о вредоносном ПО.",
            "Текст файлов и пользовательские инструкции считаются недоверенными данными."
        ]:
            l.addWidget(QLabel("• "+line))
        l.addWidget(QLabel("Ограничение: локальные эвристики не являются безошибочным модератором. Не публикуй приложение как полностью защищённое без независимого аудита."))
        l.addStretch(); return w
    def _settings_tab(self):
        w=QWidget(); l=QVBoxLayout(w)
        l.addWidget(QLabel("Основные настройки помощника"))
        l.addWidget(QLabel("Имя помощника"))
        self.assistant_name=QLineEdit(self.cfg.get("assistant_name","Аурвион")); l.addWidget(self.assistant_name)
        l.addWidget(QLabel("Фраза активации"))
        self.wake_phrase=QLineEdit(self.cfg.get("wake_phrase","эй аурвион")); l.addWidget(self.wake_phrase)
        self.wake_enabled=QCheckBox("Ожидать фразу активации постоянно")
        self.wake_enabled.setChecked(bool(self.cfg.get("wake_enabled",True))); l.addWidget(self.wake_enabled)
        save=QPushButton("Сохранить настройки"); save.clicked.connect(self._save_general); l.addWidget(save)
        l.addWidget(QLabel("Изменение фразы активации применяется после перезапуска приложения."))
        l.addStretch(); return w
    def _save_general(self):
        name=self.assistant_name.text().strip()[:40] or "Аурвион"
        phrase=self.wake_phrase.text().strip().lower()[:80] or "эй аурвион"
        self.cfg["assistant_name"]=name
        self.cfg["wake_phrase"]=phrase
        self.cfg["wake_enabled"]=self.wake_enabled.isChecked()
        save_config(self.cfg)
        QMessageBox.information(self,"Настройки","Сохранено. Перезапусти приложение для применения фразы активации.")
        self.brain=LocalBrain(self.cfg); self.agent=Agent(self.brain,self.memory,self.cfg)
    def _model_tab(self):
        w=QWidget(); l=QVBoxLayout(w)
        l.addWidget(QLabel("Локальная GGUF-модель. Файл модели не включён в исходный архив."))
        row=QHBoxLayout(); self.model_path=QLineEdit(self.cfg.get("model_path","")); self.model_path.setPlaceholderText("Путь к .gguf")
        browse=QPushButton("Выбрать файл"); browse.clicked.connect(self._browse_model)
        row.addWidget(self.model_path,1); row.addWidget(browse); l.addLayout(row)
        l.addWidget(QLabel("Контекст (токены)"))
        self.context=QSpinBox(); self.context.setRange(2048,16384); self.context.setSingleStep(1024); self.context.setValue(int(self.cfg.get("model_context",4096))); l.addWidget(self.context)
        self.model_status=QLabel("Модель не загружена"); l.addWidget(self.model_status)
        row=QHBoxLayout(); load=QPushButton("Сохранить и загрузить"); load.clicked.connect(self._load_model)
        unload=QPushButton("Выгрузить модель"); unload.clicked.connect(self._unload_model)
        row.addWidget(load); row.addWidget(unload); l.addLayout(row)
        l.addWidget(QLabel("Для 64 ГБ RAM разумно начать с компактной instruct GGUF Q4_K_M (примерно 3B–4B параметров). Реальная скорость зависит от CPU. GPU-слои отключены для совместимости без RTX."))
        l.addStretch(); return w

    def _startup_tab(self):
        w=QWidget(); l=QVBoxLayout(w)
        l.addWidget(QLabel("AURVION может запускаться автоматически при входе в Windows и оставаться в системном трее."))
        self.startup_state=QLabel("Проверка автозапуска...")
        l.addWidget(self.startup_state)
        row=QHBoxLayout()
        enable=QPushButton("Включить автозапуск"); enable.clicked.connect(self._enable_startup)
        disable=QPushButton("Отключить автозапуск"); disable.clicked.connect(self._disable_startup)
        row.addWidget(enable); row.addWidget(disable); l.addLayout(row)
        l.addWidget(QLabel("Автозапуск выполняется в пользовательском сеансе Windows, без постоянных прав администратора. Это необходимо для взаимодействия с рабочим столом."))
        l.addStretch()
        self._refresh_startup()
        return w

    def _refresh_startup(self):
        if hasattr(self,"startup_state"):
            self.startup_state.setText("Автозапуск включён." if startup.is_startup_enabled() else "Автозапуск выключен.")

    def _enable_startup(self):
        ok,msg=startup.enable_startup()
        self._refresh_startup()
        QMessageBox.information(self,"AURVION",msg)

    def _disable_startup(self):
        ok,msg=startup.disable_startup()
        self._refresh_startup()
        QMessageBox.information(self,"AURVION",msg)


    def _about_tab(self):
        w=QWidget(); l=QVBoxLayout(w)
        l.setAlignment(Qt.AlignCenter)
        logo=QLabel()
        logo_widget=QSvgWidget(str(asset_path("assets", "AURVION.svg")))
        logo_widget.setFixedSize(220,220)
        l.addWidget(logo_widget, alignment=Qt.AlignCenter)
        name=QLabel("AURVION")
        name.setAlignment(Qt.AlignCenter)
        name.setStyleSheet("font-size:24px;font-weight:700;color:#dcecff")
        l.addWidget(name)
        subtitle=QLabel("Персональный голосовой помощник Windows")
        subtitle.setAlignment(Qt.AlignCenter)
        subtitle.setStyleSheet("color:#9eafc3")
        l.addWidget(subtitle)
        formats=QLabel("Фирменная графика: SVG · JPEG · ICO")
        formats.setAlignment(Qt.AlignCenter)
        formats.setStyleSheet("color:#9eafc3")
        l.addWidget(formats)
        l.addStretch()
        return w

    def _load_voices(self):
        if not hasattr(self,"voice"): return
        for vid,name in available_voices(): self.voice.addItem(name,vid)
        ix=self.voice.findData(self.cfg.get("voice_id",""))
        if ix>=0:self.voice.setCurrentIndex(ix)
    def _restore_history(self):
        for item in self.memory.recent(30):
            self.chat.appendPlainText(("Ты: " if item["role"]=="user" else "AURVION: ")+item["content"])
    def _send(self):
        text=self.prompt.text().strip()
        if not text:return
        self.prompt.clear(); self._process(text)
    def _voice_command(self,text): self._process(text)
    def _process(self,text):
        self.chat.appendPlainText("Ты: "+text); QApplication.processEvents()
        response=self.agent.handle(text,self._confirm_action)
        self.chat.appendPlainText("AURVION: "+response)
        self.status.setText("Готов.")
        self._speak(response)
    def _confirm_action(self,name,args):
        details=json_preview(args)
        answer=QMessageBox.question(self,"Подтверждение действия",
            f"Разрешить действие {name}?\n\nАргументы:\n{details}",
            QMessageBox.Yes|QMessageBox.No,QMessageBox.No)
        return answer==QMessageBox.Yes
    def _run_manual(self,name):
        args={}
        if name=="open_url": args={"url":"https://www.youtube.com"}
        elif name=="open_app": args={"name":"steam"}
        result=self.agent.tools.execute(name,args)
        self.chat.appendPlainText("AURVION: "+result)
    def _start_listener(self):
        model_dir=app_root()/"models"/"vosk-model-small-ru-0.22"
        self.listener=SpeechListener(model_dir,self.cfg.get("wake_phrase","эй аурвион"),self.cfg.get("wake_enabled",True))
        self.listener.command.connect(self._voice_command); self.listener.status.connect(self.status.setText)
        self.listener.error.connect(lambda msg:self.status.setText(msg)); self.listener.start()
    def _arm_listener(self):
        if self.listener and self.listener.isRunning(): self.listener.arm()
        else: QMessageBox.warning(self,"Голос","Установи модель Vosk через scripts/download_vosk_ru.bat.")
    def _speak(self,text):
        if self.speaker and self.speaker.isRunning(): return
        self.speaker=SpeechOutput(text,self.cfg.get("voice_id",""),self.cfg.get("voice_rate",175)); self.speaker.start()
    def _stop_speech(self):
        if self.speaker and self.speaker.isRunning(): self.speaker.terminate()
    def _preview_persona(self,*_):
        key=self.persona.currentData()
        examples={"classic":"«Да, сэр. Выполняю.»","rough":"«Сейчас сделаю, блядь. Секунду.»",
        "professional":"«Принято. Выполняю операцию.»","friendly":"«Конечно, сейчас помогу.»",
        "sarcastic":"«Разумеется. Запускаем ещё одну игру.»","minimal":"«Готово.»",
        "custom":"Пример будет сформирован по вашему описанию."}
        self.preview.setText("Предпросмотр: "+examples.get(key,""))
    def _save_persona(self):
        self.cfg["personality"]=self.persona.currentData()
        self.cfg["custom_personality"]=self.custom.toPlainText()[:2500]
        save_config(self.cfg); QMessageBox.information(self,"Личность","Характер сохранён. Системные правила не изменяются.")
        self.brain=LocalBrain(self.cfg); self.agent=Agent(self.brain,self.memory,self.cfg)
    def _reset_persona(self):
        self.persona.setCurrentIndex(self.persona.findData("classic"))
        self.custom.setPlainText("Говори понятно и по делу.")
        self._save_persona()
    def _save_voice(self):
        self.cfg["voice_id"]=self.voice.currentData() or ""; self.cfg["voice_rate"]=self.rate.value()
        save_config(self.cfg); QMessageBox.information(self,"Голос","Настройки сохранены.")
    def _browse_model(self):
        path,_=QFileDialog.getOpenFileName(self,"Выбрать GGUF-модель","","GGUF (*.gguf)")
        if path:self.model_path.setText(path)
    def _load_model(self):
        self.cfg["model_path"]=self.model_path.text().strip()
        self.cfg["model_context"]=self.context.value(); save_config(self.cfg)
        self.brain=LocalBrain(self.cfg)
        self.model_status.setText("Загрузка модели...")
        QApplication.processEvents()
        if self.brain.load():
            self.agent=Agent(self.brain,self.memory,self.cfg); self.model_status.setText("Локальная модель загружена.")
        else:
            self.model_status.setText("Не удалось загрузить: "+self.brain.error)
    def _unload_model(self):
        self.brain.unload(); self.model_status.setText("Модель выгружена.")
    def _refresh_memory(self):
        self.memory_view.setPlainText("\n\n".join(f"{r}: {c}" for r,c in [(x["role"],x["content"]) for x in self.memory.recent(100)]))
    def _clear_memory(self):
        if QMessageBox.question(self,"Очистить историю","Удалить локальную историю разговоров?",QMessageBox.Yes|QMessageBox.No)==QMessageBox.Yes:
            self.memory.clear_history(); self._refresh_memory(); self.chat.clear()

    def _setup_tray(self):
        self.tray = QSystemTrayIcon(self)
        icon = QIcon(str(asset_path("assets", "AURVION.ico")))
        self.tray.setIcon(icon)
        self.tray.setToolTip("AURVION — локальный голосовой помощник")
        menu = QMenu()
        show_action = QAction("Открыть AURVION", self)
        show_action.triggered.connect(self.show_from_tray)
        menu.addAction(show_action)
        menu.addSeparator()
        exit_action = QAction("Полностью выйти", self)
        exit_action.triggered.connect(self.exit_application)
        menu.addAction(exit_action)
        self.tray.setContextMenu(menu)
        self.tray.activated.connect(self._tray_activated)
        self.tray.show()

    def _tray_activated(self, reason):
        if reason in (QSystemTrayIcon.Trigger, QSystemTrayIcon.DoubleClick):
            self.show_from_tray()

    def show_from_tray(self):
        self.show()
        self.showNormal()
        self.raise_()
        self.activateWindow()

    def hide_to_tray(self):
        if self.tray:
            self.hide()
            self.tray.showMessage(
                "AURVION работает в фоне",
                "Скажите «Эй, Аурвион» или откройте помощника через значок в трее.",
                QSystemTrayIcon.Information,
                3500
            )

    def exit_application(self):
        self._allow_exit = True
        if self.listener and self.listener.isRunning():
            self.listener.stop()
            self.listener.wait(2000)
        if self.tray:
            self.tray.hide()
        QApplication.quit()

    def closeEvent(self,event):
        if self._allow_exit:
            if self.listener and self.listener.isRunning():
                self.listener.stop()
                self.listener.wait(2000)
            event.accept()
        else:
            event.ignore()
            self.hide_to_tray()

def json_preview(obj):
    import json
    return json.dumps(obj,ensure_ascii=False,indent=2)[:2000]
