from __future__ import annotations
import os, shutil
from pathlib import Path

HOME = Path.home().resolve()
FOLDERS = {
    "документы": HOME / "Documents",
    "загрузки": HOME / "Downloads",
    "рабочий стол": HOME / "Desktop",
    "изображения": HOME / "Pictures",
    "музыка": HOME / "Music",
    "видео": HOME / "Videos"
}

def _safe_user_path(raw):
    p = Path(raw).expanduser().resolve()
    try:
        p.relative_to(HOME)
    except ValueError:
        raise ValueError("Разрешена работа только внутри домашней папки пользователя.")
    return p

def open_folder(name: str):
    import os
    key = str(name).lower().strip()
    path = FOLDERS.get(key)
    if path is None:
        candidate = _safe_user_path(key)
        path = candidate
    if not path.exists() or not path.is_dir():
        return "Папка не найдена."
    os.startfile(str(path))
    return f"Открываю папку: {path}"

def search_files(query: str, folder=""):
    base = _safe_user_path(folder) if folder else HOME
    if not base.exists() or not base.is_dir():
        return "Папка поиска не найдена."
    query = str(query).lower().strip()
    if not query:
        return "Укажи имя или часть имени файла."
    results = []
    for path in base.rglob("*"):
        if query in path.name.lower():
            results.append(str(path))
            if len(results) >= 30: break
    return "Найдено:\n" + ("\n".join(results) if results else "Совпадений нет.")

def copy_file(source: str, destination: str):
    src, dst = _safe_user_path(source), _safe_user_path(destination)
    if not src.is_file(): return "Ошибка: исходный файл не найден."
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)
    return f"Файл скопирован: {dst}"

def move_file(source: str, destination: str):
    src, dst = _safe_user_path(source), _safe_user_path(destination)
    if not src.exists(): return "Ошибка: исходный путь не найден."
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.move(str(src), str(dst))
    return f"Перемещено: {dst}"

def delete_file(path: str):
    target = _safe_user_path(path)
    if target == HOME:
        return "Отказ: нельзя удалить домашнюю папку пользователя целиком."
    if not target.exists(): return "Файл или папка не найдены."
    if target.is_dir():
        shutil.rmtree(target)
    else:
        target.unlink()
    return f"Удалено: {target}"
