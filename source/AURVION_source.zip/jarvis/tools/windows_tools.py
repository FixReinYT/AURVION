from __future__ import annotations
import os, subprocess, webbrowser
from pathlib import Path
from urllib.parse import urlparse

def open_url(url: str):
    parsed = urlparse(str(url))
    if parsed.scheme not in {"http","https"}:
        return "Ошибка: разрешены только адреса HTTP и HTTPS."
    webbrowser.open(str(url))
    return f"Открываю {url}"

def _start_menu_shortcuts():
    roots = [
        Path(os.environ.get("APPDATA","")) / r"Microsoft\Windows\Start Menu\Programs",
        Path(os.environ.get("PROGRAMDATA","")) / r"Microsoft\Windows\Start Menu\Programs"
    ]
    found = []
    for root in roots:
        if root.exists():
            found.extend(root.rglob("*.lnk"))
    return found

def open_app(name: str):
    name = str(name).strip().lower()
    known = {
        "steam": [Path(os.environ.get("PROGRAMFILES(X86)","C:/Program Files (x86)")) / "Steam/steam.exe",
                  Path("C:/Program Files/Steam/steam.exe")],
        "блокнот": [Path(os.environ.get("WINDIR","C:/Windows")) / "System32/notepad.exe"],
        "калькулятор": [Path(os.environ.get("WINDIR","C:/Windows")) / "System32/calc.exe"],
        "проводник": [Path(os.environ.get("WINDIR","C:/Windows")) / "explorer.exe"],
    }
    for key, paths in known.items():
        if name == key:
            for path in paths:
                if path.exists():
                    subprocess.Popen([str(path)], shell=False)
                    return f"Запускаю {key}."
    for shortcut in _start_menu_shortcuts():
        if name in shortcut.stem.lower():
            os.startfile(str(shortcut))
            return f"Запускаю {shortcut.stem}."
    return "Не нашёл приложение с таким названием в известных программах и меню Пуск."

def press_key(key: str):
    allowed = {"enter","esc","escape","tab","space","up","down","left","right","home","end","delete","backspace","ctrl","alt","shift","win","f1","f2","f3","f4","f5","f6","f7","f8","f9","f10","f11","f12"}
    key = str(key).lower().strip()
    if key not in allowed:
        return "Ошибка: эта клавиша не входит в разрешённый список."
    import pyautogui
    pyautogui.press(key)
    return f"Нажата клавиша {key}."

def click(x: int, y: int, button="left"):
    x, y = int(x), int(y)
    if not (0 <= x <= 10000 and 0 <= y <= 10000):
        return "Ошибка: координаты вне допустимого диапазона."
    if button not in {"left","right","middle"}:
        return "Ошибка: неизвестная кнопка мыши."
    import pyautogui
    pyautogui.click(x=x, y=y, button=button)
    return f"Щелчок мышью: {x}, {y}."

def type_text(text: str):
    value = str(text)
    if len(value) > 2000:
        return "Ошибка: за один вызов можно напечатать не более 2000 символов."
    import pyautogui
    pyautogui.write(value, interval=0.01)
    return "Текст введён."

def scroll(amount: int):
    amount = max(-20, min(20, int(amount)))
    import pyautogui
    pyautogui.scroll(amount)
    return f"Прокрутка: {amount}."
