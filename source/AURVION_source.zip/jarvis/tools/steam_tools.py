from __future__ import annotations
from pathlib import Path
import re, difflib, os

def steam_root():
    try:
        import winreg
        entries = [
            (winreg.HKEY_CURRENT_USER, r"Software\Valve\Steam", "SteamPath"),
            (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Valve\Steam", "InstallPath")
        ]
        for hive, key, value in entries:
            try:
                with winreg.OpenKey(hive,key) as k:
                    p=Path(winreg.QueryValueEx(k,value)[0])
                    if p.exists(): return p
            except OSError: pass
    except ImportError: pass
    for p in [Path("C:/Program Files (x86)/Steam"),Path("C:/Program Files/Steam")]:
        if p.exists(): return p
    return None

def list_games():
    root=steam_root()
    if not root: return "Steam не найден."
    libs=[root]
    vdf=root/"steamapps/libraryfolders.vdf"
    if vdf.exists():
        for m in re.finditer(r'"path"\s*"([^"]+)"',vdf.read_text(errors="ignore")):
            p=Path(m.group(1).replace(r"\\","\\"))
            if p.exists() and p not in libs: libs.append(p)
    games=[]; seen=set()
    for lib in libs:
        for f in (lib/"steamapps").glob("appmanifest_*.acf"):
            s=f.read_text(errors="ignore")
            nm=re.search(r'"name"\s*"([^"]+)"',s); aid=re.search(r'"appid"\s*"(\d+)"',s)
            if nm and aid and aid.group(1) not in seen:
                seen.add(aid.group(1)); games.append((nm.group(1),aid.group(1)))
    return "Установленные игры Steam:\n" + ("\n".join(n for n,_ in games) if games else "Не найдены.")

def launch_game(name: str):
    root=steam_root()
    if not root: return "Ошибка: Steam не найден."
    raw=list_games()
    games=[]
    libs=[root]
    vdf=root/"steamapps/libraryfolders.vdf"
    if vdf.exists():
        for m in re.finditer(r'"path"\s*"([^"]+)"',vdf.read_text(errors="ignore")):
            p=Path(m.group(1).replace(r"\\","\\"))
            if p.exists() and p not in libs: libs.append(p)
    for lib in libs:
        for f in (lib/"steamapps").glob("appmanifest_*.acf"):
            s=f.read_text(errors="ignore")
            nm=re.search(r'"name"\s*"([^"]+)"',s); aid=re.search(r'"appid"\s*"(\d+)"',s)
            if nm and aid: games.append((nm.group(1),aid.group(1)))
    if not games: return "Не найдены установленные игры Steam."
    names=[n for n,_ in games]
    exact=next((g for g in games if g[0].lower()==name.lower()),None)
    if not exact:
        matches=difflib.get_close_matches(name,names,n=3,cutoff=.48)
        if len(matches)!=1: return "Не удалось однозначно определить игру. Уточни название."
        exact=next(g for g in games if g[0]==matches[0])
    os.startfile("steam://rungameid/"+exact[1])
    return f"Запускаю {exact[0]} через Steam."
