from __future__ import annotations
from datetime import datetime
from pathlib import Path
import os

def tell_time():
    return "Сейчас " + datetime.now().strftime("%H:%M") + "."

def system_status():
    try:
        import psutil
        cpu=psutil.cpu_percent(interval=0.5)
        ram=psutil.virtual_memory()
        disks=[]
        for part in psutil.disk_partitions(all=False):
            try:
                usage=psutil.disk_usage(part.mountpoint)
                disks.append(f"{part.mountpoint}: свободно {usage.free/1024**3:.1f} ГБ")
            except Exception: pass
        return (f"Процессор: загрузка {cpu}%\n"
                f"ОЗУ: занято {ram.percent}% ({ram.used/1024**3:.1f} из {ram.total/1024**3:.1f} ГБ)\n"
                + "\n".join(disks[:8]))
    except Exception as exc:
        return "Не удалось получить диагностику: " + str(exc)

def set_volume(percent: int):
    value=max(0,min(100,int(percent)))
    try:
        from pycaw.pycaw import AudioUtilities
        AudioUtilities.GetSpeakers().EndpointVolume.SetMasterVolumeLevelScalar(value/100,None)
        return f"Громкость установлена на {value}%."
    except Exception as exc:
        return "Не удалось изменить громкость: " + str(exc)

def take_screenshot():
    try:
        import pyautogui
        folder=Path.home()/"Pictures"/"Screenshots"
        folder.mkdir(parents=True,exist_ok=True)
        path=folder/("JARVIS_"+datetime.now().strftime("%Y%m%d_%H%M%S")+".png")
        pyautogui.screenshot().save(path)
        return f"Скриншот сохранён: {path}"
    except Exception as exc:
        return "Не удалось сделать скриншот: " + str(exc)

def close_process(process_name: str):
    # Only close an exact process name after user confirmation.
    import psutil
    target=str(process_name).lower().strip()
    protected={"explorer.exe","winlogon.exe","csrss.exe","services.exe","lsass.exe","smss.exe","system"}
    if target in protected:
        return "Отказ: системный процесс защищён."
    count=0
    for proc in psutil.process_iter(["name"]):
        try:
            if (proc.info.get("name") or "").lower()==target:
                proc.terminate(); count+=1
        except (psutil.NoSuchProcess, psutil.AccessDenied): pass
    return f"Отправлен запрос на закрытие процессов: {count}."
