import sys
from PySide6.QtWidgets import QApplication
from PySide6.QtCore import QLockFile
from pathlib import Path
from jarvis.ui.main_window import MainWindow
from PySide6.QtGui import QIcon
from jarvis.core.config import asset_path

def main():
    app = QApplication(sys.argv)
    app.setApplicationName("AURVION")
    app.setOrganizationName("AURVION")
    app.setWindowIcon(QIcon(str(asset_path("assets", "AURVION.ico"))))
    app.setQuitOnLastWindowClosed(False)

    lock_path = Path.home() / "AppData" / "Local" / "AURVION" / "aurvion.lock"
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    lock = QLockFile(str(lock_path))
    if not lock.tryLock(100):
        return 0

    background = "--background" in sys.argv
    window = MainWindow(start_hidden=background)
    window.show()
    if background:
        window.hide_to_tray()
    result = app.exec()
    lock.unlock()
    return result

if __name__ == "__main__":
    sys.exit(main())
